//
//  main.h
//  Lab2
//
//  Created by Alireza on 7/6/16.
//  Copyright © 2016 Alireza. All rights reserved.
//

#ifndef main_h
#define main_h

#include <iostream>
#include <stdio.h>

#include <math.h>

#endif /* main_h */
